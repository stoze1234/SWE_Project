/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package groupproject;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Project {
    Scanner reader = new Scanner(System.in);
    private String name;
    private String projectLeader;
    int x;
    public List<Project> pList =new ArrayList<Project>();
    public List<Members> mList = new ArrayList<Members>();
    public Project(String name, String ProjectLeader)
    {
        this.name = name;
        this.projectLeader = projectLeader;
    }
    Project()
    {
        
    }
    void printMenu()
    {
        System.out.println("Press 1 and enter to create a new project.");
        System.out.println("Press 2 and then enter to view all projects by name and index.");
        System.out.println("Press 3 and enter to view a project's attriutes.");
    }
    public Project createProject(String name, String projectLeader)
    {
        this.name = name;
        return new Project(name, projectLeader);
    }
    String displayName()
    {
        return name;
    }
    void menuSwitch()
    {
        int x = reader.nextInt();
         switch (x) 
         {
            case 1:  System.out.println("Please enter the name of the new project you would like to add.");
                     String name = reader.next();
                     String projectLeader = reader.next();
                     pList.add(createProject(name,projectLeader));
                     break;
            case 2:  for(int i = 0; i < pList.size(); i++)
            {
                System.out.println("Project " + i + "'s project name is " + pList.get(i).displayName()
                );
            }
                     break;
            default: break;
         }
         continueLoop();
    }
    
    void continueLoop()
    {
        System.out.println("Would you like to continue or end session? Yes to continue or no to end");
        String response = reader.next();
        if(response.equals("yes"))
        {
            menuSwitch();
        }
        if(response == "no")
        {
            System.out.print("End of test");
        }
    }
}
