/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package groupproject;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;



/**
 *
 * @author johnn
 */
public class GroupProject {
    

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Scanner reader = new Scanner(System.in);
        List<Project> myList = new ArrayList<>();
        Project p = new Project();
        p.printMenu();
        String scanned = reader.nextLine();
        myList.add(p.createProject(scanned));
        System.out.println(myList.get(0).displayName());
        Menu();
        System.out.print("End of test");
        String scanned2 = reader.nextLine();
        
        // TODO code application logic here
    }
    static void Menu()
    {
        System.out.println("Testing method to print menu");
    }
    
}
