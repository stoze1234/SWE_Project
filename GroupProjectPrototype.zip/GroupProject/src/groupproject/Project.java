/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package groupproject;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


/**
 *
 * @author johnn
 */
public class Project {
    private String name;
    public Project(String name)
    {
        this.name = name;
    }
    Project()
    {
        
    }
    void printMenu()
    {
        System.out.println("Testing method to print");
    }
    void createList()
    {
        List<Project> pList =new ArrayList<Project>();
    }
    public Project createProject(String name)
    {
        this.name = name;
        return new Project(name);
    }
    String displayName()
    {
        return name;
    }
}
